﻿using Abp.Authorization.Roles;
using InterceptionDemo.Users;

namespace InterceptionDemo.Authorization.Roles
{
    public class Role : AbpRole<User>
    {

    }
}