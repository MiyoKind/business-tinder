﻿namespace InterceptionDemo
{
    public class InterceptionDemoConsts
    {
        public const string LocalizationSourceName = "InterceptionDemo";
    }
}